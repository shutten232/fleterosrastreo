// Firebase config – Arrived Fleteros (Realtime Database)
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyBW6R9IguNRr5WLtsTTKY6eo0rkCpkKcL0",
  authDomain: "testeoappflete.firebaseapp.com",
  databaseURL: "https://testeoappflete-default-rtdb.firebaseio.com",
  projectId: "testeoappflete",
  appId: "1:100452994973:web:71b2baa00ead371fcd6974"
};
